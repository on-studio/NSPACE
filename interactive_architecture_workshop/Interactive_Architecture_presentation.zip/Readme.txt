Windows only.
Recommended screen resolution is 1366x768, windowed.